package com.crwu.tool.netty.client;

import com.crwu.tool.netty.client.left.LeftPart;
import com.crwu.tool.netty.client.right.RightPart;
import com.yt.tool.swt.base.SwtVoid;
import com.yt.tool.swt.base.YtComposite;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.widgets.Shell;

/**
 * @author wuchengrui
 * @Description: \\TODO
 * @date 2020/8/27 19:37
 */
public class NettyClient extends YtComposite {

    public static void main(String[] args) {
    //如果报thread access 异常，在vm option中添加-XstartOnFirstThread
        SwtVoid.createSwt(shell->{
            shell.setText("netty 调试工具 - ");
            shell.setSize(800,800);
            new NettyClient(shell,0);
        });
    }


    public NettyClient(Shell shell, int i) {
        super(shell,i);
        setFillLayout();
        SashForm sashForm = new SashForm(this,0);
        LeftPart leftPart = new LeftPart(sashForm, SWT.BORDER);
        RightPart rightPart = new RightPart(sashForm, SWT.BORDER);
        sashForm.setWeights(new int[]{30,70});
    }


}
