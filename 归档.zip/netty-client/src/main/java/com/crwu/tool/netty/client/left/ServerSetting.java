package com.crwu.tool.netty.client.left;

import com.yt.tool.swt.base.YtComposite;
import com.yt.tool.swt.ui.text.YtText;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Group;

/**
 * @author wuchengrui
 * @Description: \\TODO
 * @date 2020/8/27 19:43
 */
public class ServerSetting extends YtComposite {

    public ServerSetting(Composite parent, int style) {
        super(parent, style);

        Group group = new Group(parent,0);
        group.setText("服务端设置");
        group.setLayout(new FillLayout());

        setParent(group);

        setGridLayout(2,false);
        init();
    }

    private void init(){
        createLabel("目标ip：");
        YtText ipText = new YtText(this, SWT.BORDER);
        ipText.setGdFill(true,false);

        createLabel("目标端口：");
        YtText portText = new YtText(this, SWT.BORDER);
        portText.setGdFill(true,false);

    }




}
