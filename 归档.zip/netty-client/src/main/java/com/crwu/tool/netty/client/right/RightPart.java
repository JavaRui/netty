package com.crwu.tool.netty.client.right;

import com.yt.tool.swt.base.YtComposite;
import org.eclipse.swt.widgets.Composite;

/**
 * @author wuchengrui
 * @Description: \\TODO
 * @date 2020/8/27 19:41
 */
public class RightPart extends YtComposite {
    public RightPart(Composite parent, int style) {
        super(parent, style);
    }
}
